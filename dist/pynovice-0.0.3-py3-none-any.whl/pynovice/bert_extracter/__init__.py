# coding=utf-8
# /usr/bin/env python

'''
Author: wenqiangw
Email: wenqiangw@opera.com
Date: 2020-03-25 14:40
Desc:
'''
from bert_extracter import ExtractBertFeatures,DownloadBertModel
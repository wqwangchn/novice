# novice

1.geo_map: reverse Geocoder takes a latitude / longitude coordinate and returns the nearest town/city.
2.bert_extracter: load bert_vector

